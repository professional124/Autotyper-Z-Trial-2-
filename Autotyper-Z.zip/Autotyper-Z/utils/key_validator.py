# Subscription key validator
